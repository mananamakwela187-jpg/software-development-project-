/*
*=======================================================
*CLASS: MedicalIncident (SUBCLASS)
*=======================================================
* 'extends EmergencyIncident' = INHERITANCE.
* It automatically gets all the fields and methods of the parent
* class, so we therefore only write what is Different for medical 
* incidents
*/
public class MedicalIncident extends EmergencyIncident {
    // CONSTRUCTOR : this is because it takes the same values as the parent class and 
    // and passes them up using super clss, which runs the parent constructor 
    // (including all its validation).
    public MedicalIncident(String incidentId, String location, int peopleAffected,
                    int severityLevel, int responseTime, int assignedUnits){
        super(incidentId, location, peopleAffected, severityLevel, responseTime, assignedUnits);      
    }
    // @Override in Java tells it that we now providing our own version of the 
    // parent's abstract method. Medical emergency now need 2 units
    @Override
    public int getRequiredUnits() {
        return 2;
    }   
    // The name is now then displayed to the user for this emergency type.    
    @Override
    public String getEmergencyType(){
        return "Medical Emergency";
    }       
}