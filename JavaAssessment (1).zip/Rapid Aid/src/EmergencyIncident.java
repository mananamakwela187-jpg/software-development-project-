/*
 * =============================================================================
 *CLASS: EmergencyIncident(Abstract Class)
 * =============================================================================
 * We used the abstract class as it holds everything that Medical and Fire-incidents
 * have in common whihc is the ID, Location, severity, etc
 * An object of an abstract cannot be created directly.
 * e.g new EmergencyIncident(...) is not allowed. Only the subclasses like Medical 
 * Incident, FireIncident are allowed to be created.
 *
 * OOP CONCEPTS DEMONSTRATED HERE:
 *  >Abstract class + abstract method
 *  >Encapsulation (private fields + getters/setters)
 *  >Constructor(parameterised)
 *  > Method overloading ( calculateResourceRequirement)
 */
public abstract class EmergencyIncident{
    // -------------------------------------------------------------------------
    // FIRST STEP: Instance variables (Encapsulation)
    // All are 'private' so no other class can change the directly 
    // And that other classes must use the getters/setters below
    // and the setters CHECK (validate) the value before accepting it.
    // -------------------------------------------------------------------------
    
    private String incidentId;
    private String location;
    private int peopleAffected;
    private int severityLevel; // 1 being minor 5 being critical
    private int responseTime;  // the estimatyed time response in minutes 
    private int assignedUnits; // response units that are currently assigned
    
    // -------------------------------------------------------------------------
    // Second Step: Parameterised Constructor
    // This runs when a subclass does super(..). Instead of assigning the 
    // fields directly (this.x = x), we call the SETTERS so that the SETTERS
    // validate rules are applied every time an object is created 
    // -------------------------------------------------------------------------
    public EmergencyIncident(String incidentId, String location, int peopleAffected,
                 int severityLevel, int responseTime, int assignedUnits) {
        setIncidentId (incidentId);
        setLocation(location);
        setPeopleAffected(peopleAffected);
        setSeverityLevel(severityLevel);
        setResponseTime(responseTime);
        setAssignedUnits(assignedUnits);
    }
    // -------------------------------------------------------------------------
    // Third Step: Abstract Methods
    // Have no body and each subclass Must provide its own 
    // version (this is what makes polymorphism possible)
    // Instead of -> 2 units FireIncidents need ->4 units
    // -------------------------------------------------------------------------
     public abstract int getRequiredUnits();
     
     //This then returns the name of the emergency type e.g, "Fire Emergency"
     public abstract String getEmergencyType();
     
     // ------------------------------------------------------------------------
     // Fourth step : Getters 
     // Allow other  classes to READ the private fields.
     // ------------------------------------------------------------------------
     
     public String getIncidentId() {return incidentId;}
     public String getLocation() {return location;}
     public int getPeopleAffected() { return peopleAffected;}
     public int getSeverityLevel() {return severityLevel;}
     public int getResponseTime() { return responseTime;}
     public int getAssignedUnits() {return assignedUnits;}
     
     // ------------------------------------------------------------------------
     // Fifth Step: Setters with validation
     // The setters are declared 'final' so that the subclasses cannot override them.
     // This makes it safer for the constructor to call them (calling an override 
     // method from a constructor is risky). 
     // If the value is invalid we THROW an exception, which stops the object being created/updated  
     //  with bad data
     // ------------------------------------------------------------------------
     
     // ID must not be blank.trim()removes spaces, toUpperCase() makes 
     // "inc1001" and "INC1001" the same ID.
     public final void setIncidentId(String incidentId) {
         if (incidentId == null || incidentId.trim().isEmpty() ) {
             throw new IllegalArgumentException("Incident ID cannot be empty.");
         }
         this.incidentId = incidentId.trim().toUpperCase();
     
    }
     // LOCATION MUST NOT BE BLANK.
     public final void setLocation(String location) {
         if (location == null || location.trim().isEmpty()) {
             throw new IllegalArgumentException("Location cannot be empty.");
         }
         this.location = location.trim();
     }
      // You cannot have negative number of people.
     public final void setPeopleAffected(int peopleAffected){
         if (peopleAffected < 0) {
             throw new IllegalArgumentException("Number of people affected cannot be negative");
         }
         this.peopleAffected = peopleAffected;
     }
     // Severity must be one of the from the breif : 1-5.
     public final void setSeverityLevel(int severityLevel) {
         if (severityLevel < 1 || severityLevel >5 ) {
             throw new IllegalArgumentException("Severity level must be between 1 and 5.");
         }
         this.severityLevel = severityLevel;
     
     }
      // Response time cannot be negative.
     public final void setResponseTime(int responseTime) {
         if (responseTime < 0) {
             throw new IllegalArgumentException("Estimated response time cannot be negative.");
         }
         this.responseTime = responseTime;
     }
     // Menu option 3 ("Update Assigned Units") uses this setter.
     // Negative values are rejected, as the brief requires.
     public final void setAssignedUnits(int assignedUnits) {
         if (assignedUnits < 0) {
             throw new IllegalArgumentException("Assigned units cannot be negative.");
         }
         this.assignedUnits = assignedUnits;
     }
     // ------------------------------------------------------------------------
     // Sixith: Priority Score 
     // Formula from the brief
     // (Severity * 20) + (People Affected * 2) - (Response Time / 5)
     // We divide by 5.0 (not 5) so that Java does DECIMAL division.
     // This is because if we divide by 50.0 (not 5)an integer Java would drop the decimals
     // 15/5 is fine
     // but 12/5 would become 2 instead of 2.4 which is wrong
     // But if the answer is under 0 we return 0 instead.
     // ------------------------------------------------------------------------
     public double calculatePriorityScore() {
         double score = (severityLevel * 20) + (peopleAffected * 2) - (responseTime / 5.0);
         if(score < 0) {
             return 0;
         }
         return score;
     }
     // ------------------------------------------------------------------------
     // Seventh Step: Response Level (Selection / if-else)
     // This makes use of the score ranges from the brief:
     // below 40 -> Routine
     // 40 - 69.9 -> Urgent 
     // 70 and up -> Critical
     // ------------------------------------------------------------------------
     public String getResponseLevel() {
         double score = calculatePriorityScore();
         if (score < 40) {
             return "Routine";
         }else if (score < 70) {
             return "Urgent";
         }else {
             return "Critical";
         }
     }
     // ------------------------------------------------------------------------
     // Eighth Step : Message shown in the priority report (menu option 4)
     // Each response level has its own specific brief message 
     // ------------------------------------------------------------------------
     public String getResponseMessage() {
         String level  = getResponseLevel();
         if (level.equals("Routine")) {
             return "The incident can be handled through normal response procedures.";
         }else if (level.equals("Urgent")) {
             return "The incident requires prompt attention from the response team";
         }else {
             return "Immediated response coordination is required.";
         }
     }
     
     // ------------------------------------------------------------------------
     // Ninth Step : Method Overloading 
     // Two methods with the Same Name but Different parameters
     //
     // The first version - no parameter: uses the incident's own assigned units.
     // It just calls version 2 and passes the assignedUnits to it.
     // ------------------------------------------------------------------------
     public int calculateResourceRequirement() {
         return calculateResourceRequirement(assignedUnits);
     }
     // The second version takes the number of available units as a parameter
     // getRequiredUnits() is the ABSTRACT method: for a FireIncident, it returns 4 instead
     // of 2 for MedicalIncident (polymorphism).
     // Returns the amount of units are needed (Never below 0)
     public int calculateResourceRequirement(int availableUnits) {
         int additional = getRequiredUnits() - availableUnits;
         if (additional > 0) {
             return additional;
         }
         return 0;
     }
     // ------------------------------------------------------------------------
     // Tenth Step :Resources Status
     // Enough units assigned (assigned >= required) -> Sufficient.
     // ------------------------------------------------------------------------
     public String getResourceStatus() {
         if (assignedUnits >= getRequiredUnits()) {
             return "Sufficient Resources";
         }else {
             return "Insufficient Resources";
         }
     }
}   



