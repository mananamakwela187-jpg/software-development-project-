import java.util.ArrayList; // needed for the ArrayList that stores incident
import java.util.Scanner;   // needed for reading the keyboard input
/*
*====================================================
*CLASS: Main (APPLICATION CLASS)
*====================================================
* This contains main(). which is the menu, all user input, and the code for
* each menu option. Each menu option has its own METHOD so that main() so that it
* is short and easy to ("the "Methods" requirement).
*/
public class Main {
    // First Step: SHARED DATA
    // 'static' = belongs to the class, so that every static method below
    // can be used without passing the around.
    //
    // incidents is the ArrayList of the PARENT type. This is because of 
    // POLYMORPHISM, as it can hold both MedicalIncident and FireIncident object 
    // in the same list.
    // --------------------------------------------------------------------------
    private static final String LINE = "=======================================";
    private static final Scanner input = new Scanner(System.in);
    private static final ArrayList<EmergencyIncident> incidents = new ArrayList<>();
    //---------------------------------------------------------------------------
    // Second Step: main() - THE MENU LOOP (LOOPS requirement)
    // do-while runs the body for a minimum of one time, then repeats while the
    // user has NOT chosen 7 (Exit).
    //---------------------------------------------------------------------------
    public static void main (String[] args){
        int choice;
        do {
            displayMenu();                      // show the menu
            choice = readInt("Enter your choice:"); // read option
            
            // switch = SELECTION: run the method matching the choice.
            // 'break' stops it falling through into the next case.
            switch (choice){
                case 1 -> registerIncident();
                case 2 -> viewIncident();
                case 3 -> updateAssignedUnits();
                case 4 -> viewPriorityReport();
                case 5 -> checkResourceStatus();
                case 6 -> viewAllIncidents();
                case 7 -> System.out.println("Exiting RapidAid Emergency Service. Goodbye.");
                default -> // anything that is not 1-7
                    System.out.println("Invalid choice. Please select 1 to 7.");
                    
            }
        }while(choice != 7);
        
    }
    // --------------------------------------------------------------------------
    // STEP 3: DISPLAY THE MENU (matches the layout in the brief)
    // --------------------------------------------------------------------------
    private static void displayMenu(){
        System.out.println();
        System.out.println(LINE);
        System.out.println(" RAPIDAID EMERGENCY SERVICES");
        System.out.println(LINE);
        System.out.println("1. Register Incident");
        System.out.println("2. View Incident");
        System.out.println("3. Update Assigned Units");
        System.out.println("4. View Priority Report");
        System.out.println("5. Check Resources Status");
        System.out.println("6. View All Incidents");
        System.out.println(" 7.Exit");
        System.out.println(LINE);     
    }
    // ==========================================================================
    // STEP 4: INPUT HELPER METHODS (VALIDATION)
    // They keep asking until the user types something valid, so the programs 
    // never crashes on bad input like "abc"
    // ==========================================================================
    
    // Reads a whole number. We read a full line and convert it with Integer.parselnt.
    // If the user typed letter, parselnt throws NumberFormException;(invalid conversion
    // of a string to a numeric format) with we are able to catch and ask again.
    // (Readding with nextLine() everywhere avoids the classic Scanner 
    // bug where nextInt() leaves the Enter key in the buffer.)
    private static int readInt(String prompt) {
        while (true) {
            System.out.println(prompt);
            String text = input.nextLine().trim();
            try {
                return Integer.parseInt(text);
            }catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a whole number.");
            }
        }
    }
    // Heads a number that must be between min and max (e.g severity 1-5).
    private static int readIntInRange(String prompt, int min, int max) {
        while (true) {
            int value = readInt(prompt);
            if (value >= min && value <= max) {
                return value;
            }
            System.out.println("Value must be between" + min + "and" + max + ".");
        }  
    }
    // Reads a number that must not be negative (people, minutes, units).
    private static int readNonNegativeInt(String prompt) {
        while(true) {
            int value = readInt(prompt);
            if (value >= 0) {
                return value;
            }
            System.out.println("Value cannot be negative.");
        }
    }
        // Reads text that must not be blank(ID, location).
        private static String readNonEmpty(String prompt) {
            
            while (true) {
                System.out.println(prompt);
                String text = input.nextLine().trim();
                if (!text.isEmpty()){
                    return text;
                }
                System.out.println("This field cannot be empty.");
                
            }
        }
        // ====================================================================
        // Fifth Step : Searching the arraylist
        // ====================================================================
        
        // Loops through every incident and compares IDs (ignoring upper/ lower case)
        // Returns the incident if found, or null if not
        private static EmergencyIncident findIncident(String id) {
            for (EmergencyIncident incident : incidents) {
                if (incident.getIncidentId().equalsIgnoreCase(id.trim())) {
                    return incident;            
                }
            }
            return null; // null = "not found"
        }
        // Ask the user for an ID and finds it. Options 2, 3, 4 & 5 all
        // need this, so we wrote it once and reuse it (no response code).
        // Prints the "not found" message and returns null if missing.
        private static EmergencyIncident promptForIncident() {
            String id = readNonEmpty("Enter Incident ID:");
            EmergencyIncident incident = findIncident(id);
            if (incident == null) {
                System.out.println("Incident ID" + id + "was not found");
            }
            return incident;    
        }
        // ==============================================================
        // OPTION 1: Register incident
        // ==============================================================
        private static void registerIncident(){
            System.out.println("\n--- Register Incident ---");
            // A) The incident ID must be UNIQUE (an assumption in the brief).
            // Keep asking until the ID is not already in the list.
            String id;
            while (true) {
                id = readNonEmpty("Enter Incident ID:");
                if(findIncident(id) == null) {
                    break; //ID is free, keave the loop
                }
                System.out.print("An incident with that ID already exists. Enter a unique ID.");       
            }
            // b) Location 
            String location = readNonEmpty("Enter Location: ");
            
            // c) Emergency type - only 1 (Medical) or 2 (Fire) are aloowed
            int type;
            while (true) {
                System.out.println("Emergency Type.");
                System.out.println("1. Medical Emergency");
                System.out.println("2. Fire Emergency");
                type = readInt("Select type:");
                if (type == 1 || type ==2) {
                    break;                   
                }
                System.out.println("Invalid emergency type. Select 1 or 2.");
                
            }
            // d) The numeric details, each validated by a helper method.
            int people = readNonNegativeInt("Enter Number of People Affected:");
            System.out.println("Severity Levels: 1Minor, 2 Moderate, 3 Serious, 4 Severe, 5 Critical");
            int severity = readIntInRange ("Enter Severity Level (1-5):", 1,5);
            int responseTime = readNonNegativeInt("Enter Estimated Response Time(minutes)");
            int assigned = readNonNegativeInt("Enter Number of Response Units Assigned:");
            
            //e) Create the correct object type using the PARAMETERISED
            // constructor.The variable type is the PARENT class
            // (EmergencyIncident) but the object is a medical/fire one.
            // This is method is known as POLYMORPHISM
            EmergencyIncident incident;
            if (type == 1) {
                incident = new MedicalIncident(id, location, people, severity, responseTime, assigned);               
            }else {
                incident = new FireIncident(id, location, people, severity, responseTime, assigned);
            }
            //f) Store it in the ArrayList and confirm to the user.
            incidents.add(incident);
            System.out.println("Incident" + incident.getIncidentId() + "registered successfully.");      
        }
        // =======================================================================
        //OPTION 2: VIEW INCIDENT
        // =======================================================================(
        private static void viewIncident() {
            System.out.println("\n--- View Incident---");
            
            EmergencyIncident i = promptForIncident();
            if (i == null) {
                return; //not found: message already shown, go back to the menu
        }
        
        // printf formatting: %s = text, %d = whole number,
        // %.2f = decimal with 2 places(97.00), %n = new line.
        System.out.println();
        System.out.println(LINE);
        System.out.println(" INCIDENT DETAILS");
        System.out.println(LINE);
        System.out.printf("Incident ID:  %s%n", i.getIncidentId());
        System.out.printf("Location: %s%n", i.getLocation());
        System.out.printf("Emergency Type: %s%n", i.getEmergencyType());
        System.out.println();
        System.out.printf("People Affected: %d%n", i.getPeopleAffected());
        System.out.printf("Severity Level: %d%n",i.getSeverityLevel());
        System.out.printf("Response Time: %d minutes%n", i.getResponseTime());
        System.out.println();
        System.out.printf("Assigned Units: %d%n", i.getAssignedUnits());
        System.out.printf("Required Units: %d%n", i.getRequiredUnits());
        System.out.println();
        System.out.printf("Priority Score: %.2f%n", i.calculatePriorityScore());
        System.out.printf("Response Level: %s%n", i.getResponseLevel());
        System.out.printf("Resource Status: %s%n", i.getResourceStatus());
        System.out.println(LINE);
                
            
        }
        // ======================================================================
        // OPTION 3 : Update Assigned units
        // ======================================================================
        private static void updateAssignedUnits(){
            System.out.println("\n--- Update Assigned Units ---");
            
            EmergencyIncident i = promptForIncident();
            if (i == null){
                return;
            }
            System.out.println("Current Assigned Units" + i.getAssignedUnits());
            int newUnits = readInt("Enter New Assigned Units:");
            
            //The brief says: reject negative values.
            if (newUnits < 0) {
                System.out.println("Negative values are not allowed. Update rejected.");
                return;
                
            }
             // After we update the value we then show the RECALCULATE resources status
             // (getResourcesStatus() works it out fresh each time it is called).
             i.setAssignedUnits(newUnits);
             System.out.println("Assigned units successfully update.");
             System.out.println("Resources Status:" + i.getResourceStatus());    
        }   
        // =======================================================================
        // OPTION 4: View the priority report
        // =======================================================================
        private static void viewPriorityReport() {
            System.out.println("\n--- View Priority Report ---");
            
            EmergencyIncident i = promptForIncident();
            if (i == null) {
                return;
            }
            System.out.println();
            System.out.println(LINE);
            System.out.println("   PRIORITY REPORT");
            System.out.print(LINE);
            System.out.println("Incident ID" + i.getIncidentId());
            System.out.printf("Priority Score: %.2f%n", i.calculatePriorityScore());
            System.out.println("Response Level:" + i.getResponseLevel());
            System.out.println();
            System.out.println(i.getResponseMessage()); // message for that level
            System.out.println(LINE);       
        }
        // ======================================================================
        // OPTION 5: We now then check resources status
        // ======================================================================
        private static void checkResourceStatus() {
            System.out.println("\n--- Check Resource Status ---");
            
            EmergencyIncident i = promptForIncident();
            if (i == null) {
                return;
            }
            System.out.println();
            System.out.println("Required Units: " + i.getRequiredUnits());
            System.out.println("Assigned Units: " + i.getAssignedUnits());
            //The OVERLOADED method with no parameters is used
            System.out.println("Additional Units Needed:" + i.calculateResourceRequirement());
            System.out.println("Resource Status:" + i.getResourceStatus());  
        }
        // ======================================================================
        // OPTION 6: We now view all INCIDENTS
        // ======================================================================
        private static void viewAllIncidents() {
            // If the list is empty, we then show the message from  the brief.
            if(incidents.isEmpty()) {
                System.out.println("No incidents have been registered");
                return;
            }
            System.out.println();
            System.out.println(LINE + "===");
            System.out.println("  REGISTERED INCIDENTS");
            System.out.println(LINE + "===");
            // %-10s = text padded to 10 characters, left-aligned in neat columns
            System.out.printf("%-10s %-18s %-18s %-8s %s%n", "ID", "Location", "Type", "Score", "Level");
            System.out.println("-------------------------------------------------------");
            
            //For-each loop: visit every incident in the ArrayList.
            for (EmergencyIncident i : incidents) {
                System.out.printf("%-10s %-18s %-18s %-8.2f %s%n",
                        i.getIncidentId(), i.getLocation(), i.getEmergencyType(),
                        i.calculatePriorityScore(), i.getResponseLevel());
            }
            System.out.println(LINE + "====");   
    }    
}
