/* 
* ================================================
* CLASS: FireIncident (SUBCLASS)
* ================================================
* This has the same idea as MedicalIncident, but the difference is that
*fire emergency are bigger so instead of 2 units they need 4 response units
*/
public class FireIncident extends EmergencyIncident {
    // Pass everything up to the parent constructor with super.
    public FireIncident(String incidentId, String location, int peopleAffected,
                  int severityLevel, int responseTime, int assignedUnits) {
        super(incidentId, location, peopleAffected, severityLevel, responseTime, assignedUnits);
    }
    @Override
    public int getRequiredUnits(){
        return 4;
    }
    // The name is then shown to the user
    @Override 
    public String getEmergencyType(){
        return "Fire Emergency";
    } 
}
