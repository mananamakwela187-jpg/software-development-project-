"""
=============
Name:  Enter Name Here
Date: 06 June 2026
Programme purpose:
=============
"""

import tkinter as tk
from tkinter import messagebox

# Initialize and hide the blank root Tkinter window frame to keep UI clean
root = tk.Tk()
root.withdraw()

# Global list to store all registered learner objects
learners_list = []


# REQUIREMENT 2 & 3: OBJECT-ORIENTED STRUCTURE & INHERITANCE
# ==========================================
class Person:
    """Base class holding shared common person data."""

    def __init__(self, name, age):
        self.name = name
        self.age = age


class Learner(Person):
    """Derived class inheriting from Person Class ."""

    def __init__(self, learner_id, name, age, course):
        # Trigger parent constructor to fulfill inheritance mapping
        super().__init__(name, age)
        self.learner_id = learner_id
        self.course = course
        self.marks = []  # List container for assessment marks

        # REQUIREMENT 3 ENCAPSULATION: Protected attribute matching structural criteria
        self._performance_status = "No Marks Logged"

    # Encapsulation Access Methods (Getter and Setter Logic)
    def get_performance_status(self):
        """Getter to retrieve protected evaluation metrics safely."""
        return self._performance_status

    def set_performance_status(self, updated_status):
        """Setter to modify metrics through systemic validation rules."""
        self._performance_status = updated_status


# ==========================================
# REQUIREMENT 7 & 8: RECURSIVE METHODS & CORE UTILITY FUNCTIONS
# ==========================================
def recursive_sum_marks(marks_list, index=0):
    """This fulfills Requirement 8: Processes the summation of marks using recursion."""
    if index == len(marks_list):
        return 0
    return marks_list[index] + recursive_sum_marks(marks_list, index + 1)


def check_certificate_eligibility(average_score):
    """Fulfills Requirement 7 (Predicate Function): Returns conditional boolean state."""
    # Requirement 5: Decision Structure checking pass baseline
    if average_score >= 50:
        return True
    else:
        return False


def print_system_banner(title_text="===== Learner Progress Tracking System ====="):
    """Fulfills Requirement 7 (Function with Default Argument): Configures standard layouts."""
    print("\n" + title_text)


# ==========================================
# REQUIREMENT 1, 4, 9 & 10: ADMINISTRATIVE LOGIC & ERROR HANDLING
# ==========================================
def find_learner_by_id(target_id):
    """Traverses and searches through the list container for matching IDs."""
    for learner in learners_list:
        if learner.learner_id == target_id:
            return learner
    return None


def register_new_learner():
    """Captures input strings/ints, validates parameters, and registers learner instances."""
    print_system_banner("--- Add New Learner Configuration ---")

    # Requirement 9: Try-Except Block targeting registration mapping exceptions
    try:
        learner_id_input = int(input("Enter learner ID: ").strip())

        # Avoid duplication conflicts across identity lookups
        if find_learner_by_id(learner_id_input) is not None:
            messagebox.showerror(
                "Invalid Input", f"ID {learner_id_input} already exists within records.")
            return

        name_input = input("Enter learner name: ").strip()
        if not name_input:
            messagebox.showwarning(
                "Warning", "Name parameter cannot stay blank.")
            return

        age_input = int(input("Enter learner age: ").strip())

        # Requirement 5: Validating bounds using structural decisions
        if age_input < 5 or age_input > 100:
            messagebox.showerror(
                "Invalid Input", "Age boundary parameters must fit between 5 and 100.")
            return

        course_input = input("Enter course name: ").strip()
        if not course_input:
            messagebox.showwarning(
                "Warning", "Course description field is mandatory.")
            return

        # Instantiate structural entity matching configuration mapping
        new_learner = Learner(
            learner_id=learner_id_input,
            name=name_input,
            age=age_input,
            course=course_input
        )

        # Append target instance into collection array tracking context records
        learners_list.append(new_learner)

        # Requirement 11: Prompt GUI success tracking notice
        messagebox.showinfo("Success", "Learner added successfully.")

    except ValueError:
        messagebox.showerror(
            "Format Error", "Numeric properties require clean, integer values.")


def capture_assessment_marks():
    """Appends array entries tracking student metrics across academic criteria."""
    print_system_banner("--- Record Course Assessment Marks ---")

    try:
        search_id = int(input("Enter learner ID: ").strip())
        target_student = find_learner_by_id(search_id)

        if target_student is None:
            messagebox.showwarning(
                "Not Found", "No student matches the provided ID mapping.")
            return

        quantity_input = int(
            input("How many marks do you want to enter? ").strip())
        if quantity_input <= 0:
            print("Invalid quantity count requested. Terminating operation pipeline.")
            return

        # Requirement 6: Step through iterative cycles parsing mark boundaries
        for item_index in range(1, quantity_input + 1):
            while True:
                try:
                    raw_mark = float(
                        input(f"Enter mark {item_index}: ").strip())

                    # Requirement 5: Double-ended validation rules checking constraints
                    if 0.0 <= raw_mark <= 100.0:
                        target_student.marks.append(raw_mark)
                        break  # Break out of loop once value is verified
                    else:
                        print(
                            "Evaluation out of bounds. Score scales must read between 0 and 100.")
                        continue  # Clear iteration space to prompt for corrected score entry
                except ValueError:
                    print(
                        "Invalid scalar type. Provide a decimal or base integer form.")

        # Recalculate averages and refresh protected structural parameters
        total_score = recursive_sum_marks(target_student.marks)

        try:
            calculated_avg = total_score / len(target_student.marks)
        except ZeroDivisionError:
            calculated_avg = 0.0

        # Requirement 4 & 5: Determine performance category boundaries
        if calculated_avg < 50.0:
            performance_tier = "Fail"
        elif 50.0 <= calculated_avg < 75.0:
            performance_tier = "Pass"
        else:
            performance_tier = "Pass with distinction"

        # Apply updates via internal encapsulation protocols
        target_student.set_performance_status(performance_tier)

        # Trigger GUI popup reporting processing confirmation
        messagebox.showinfo("System Message", "Marks captured successfully.")

    except ValueError:
        messagebox.showerror(
            "Entry Violation", "Numerical processing keys must contain proper formatting rules.")


def view_all_registered_records():
    """Traverses and yields status outputs across current collection contexts."""
    print_system_banner("--- Global Student Summary Registry ---")

    if not learners_list:
        print("Empty directory context. No registered records exist currently.")
        return

    # Process iteration pathways parsing collection arrays sequentially
    for student in learners_list:
        try:
            total_score = recursive_sum_marks(student.marks)
            avg_score = total_score / len(student.marks)
        except ZeroDivisionError:
            avg_score = 0.0

        # Requirement 7: Call check_certificate_eligibility using Keyword Argument patterns
        qualified_state = check_certificate_eligibility(
            average_score=avg_score)
        cert_string = "Yes" if qualified_state else "No"

        # Requirement 12: Output formatting matching terminal display parameters
        print(f"\n----- Learner Summary -----")
        print(f"Learner ID: {student.learner_id}")
        print(f"Name: {student.name}")
        print(f"Age: {student.age}")3
        print(f"Course: {student.course}")
        print(f"Marks: {student.marks}")
        print(f"Average: {avg_score:.2f}")
        # Pulled cleanly using getter logic
        print(f"Result: {student.get_performance_status()}")
        print(f"Certificate: {cert_string}")


def search_single_record():
    """Filters data spaces directly tracking specialized search patterns."""
    print_system_banner("--- Query Learner Profile ---")
    try:
        search_query_id = int(input("Enter learner ID to search: ").strip())
        matched_profile = find_learner_by_id(search_query_id)

        if matched_profile is None:
            print(
                "Target matching individual couldn't be located inside current records.")
            return

        try:
            computed_sum = recursive_sum_marks(matched_profile.marks)
            computed_avg = computed_sum / len(matched_profile.marks)
        except ZeroDivisionError:
            computed_avg = 0.0

        certificate_allowed = "Yes" if check_certificate_eligibility(
            computed_avg) else "No"

        print(f"\n----- Learner Summary -----")
        print(f"Learner ID: {matched_profile.learner_id}")
        print(f"Name: {matched_profile.name}")
        print(f"Age: {matched_profile.age}")
        print(f"Course: {matched_profile.course}")
        print(f"Marks: {matched_profile.marks}")
        print(f"Average: {computed_avg:.2f}")
        print(f"Result: {matched_profile.get_performance_status()}")
        print(f"Certificate: {certificate_allowed}")

    except ValueError:
        messagebox.showerror(
            "Input Error", "ID structures only process structural integer inputs.")


def modify_learner_profile():
    """Modifies existing object properties dynamically."""
    print_system_banner("--- Update Profile Framework ---")
    try:
        lookup_id = int(input("Enter learner ID to update: ").strip())
        profile_instance = find_learner_by_id(lookup_id)

        if profile_instance is None:
            print(
                "The specified identity track is completely missing from database arrays.")
            return

        updated_name = input("Enter new name: ").strip()
        updated_age_string = input("Enter new age: ").strip()
        updated_course = input("Enter new course: ").strip()

        # Update variable spaces only if new non-empty inputs are parsed
        if updated_name:
            profile_instance.name = updated_name
        if updated_age_string:
            try:
                numeric_age = int(updated_age_string)
                if 5 <= numeric_age <= 100:
                    profile_instance.age = numeric_age
                else:
                    print("Age constraint bounds failed. Leaving properties unchanged.")
            except ValueError:
                print("Incorrect pattern. Age processing update discarded.")
        if updated_course:
            profile_instance.course = updated_course

        messagebox.showinfo("Updated", "Learner details updated successfully.")

    except ValueError:
        messagebox.showerror(
            "Error Context", "Numerical conversion processing dropped due to pattern mismatch.")


def terminate_learner_record():
    """Removes matching target array components from global tracking spaces."""
    print_system_banner("--- Purge Learner Profiles ---")
    try:
        deletion_target_id = int(input("Enter learner ID to remove: ").strip())
        found_profile = find_learner_by_id(deletion_target_id)

        if found_profile is None:
            print("Target tracking index matching entry parameters cannot be located.")
            return

        # Extract target object instance safely out of array data spaces
        learners_list.remove(found_profile)
        messagebox.showinfo("Deleted", "Learner removed successfully.")

    except ValueError:
        messagebox.showerror(
            "Input Exception", "Target references require valid numerical identification IDs.")


def display_specific_result_box():
    """Prints explicit score calculations and triggers graphical conditional confirmations."""
    print_system_banner("--- Render Performance Overview ---")
    try:
        target_student_id = int(input("Enter learner ID: ").strip())
        student_instance = find_learner_by_id(target_student_id)

        if student_instance is None:
            print("Identity index records are missing targeted profile signatures.")
            return

        try:
            total_sum = recursive_sum_marks(student_instance.marks)
            calculated_average = total_sum / len(student_instance.marks)
        except ZeroDivisionError:
            calculated_average = 0.0

        # Output results to terminal interface window
        print(f"\nResult for {student_instance.name}")
        print(f"Average: {calculated_average:.2f}")
        print(f"Performance: {student_instance.get_performance_status()}")

        # Requirement 11: Display pass/fail result graphical status boxes conditionally
        if check_certificate_eligibility(calculated_average):
            messagebox.showinfo(
                "Result", f"{student_instance.name} qualifies for a certificate.")
        else:
            messagebox.showwarning(
                "Result", f"{student_instance.name} does not meet certificate standard baselines.")

    except ValueError:
        messagebox.showerror(
            "Error", "Numerical parameters require standardized processing inputs.")


# ==========================================
# REQUIREMENT 6: SYSTEM ENTRY POINT MAPPING (MAIN CONSOLE LOOP)
# ==========================================
def run_system_orchestrator():
    """Handles core loop execution interfaces and traps structural runtime faults."""
    while True:
        # Fulfills Default Argument criteria via empty invocation parameter rules
        print_system_banner()
        print("1. Add learner")
        print("2. Enter marks")
        print("3. View all learners")
        print("4. Search learner")
        print("5. Update learner")
        print("6. Remove learner")
        print("7. Show learner result")
        print("8. Exit")

        try:
            menu_selection = int(input("Enter your choice: ").strip())
        except ValueError:
            # Trap menu validation format errors cleanly without structural interruptions
            messagebox.showerror(
                "Selection Error", "Menu interactions require clean integer commands.")
            continue

        # Map inputs directly to distinct sub-module operations pipelines
        if menu_selection == 1:
            register_new_learner()
        elif menu_selection == 2:
            capture_assessment_marks()
        elif menu_selection == 3:
            view_all_registered_records()
        elif menu_selection == 4:
            search_single_record()
        elif menu_selection == 5:
            modify_learner_profile()
        elif menu_selection == 6:
            terminate_learner_record()
        elif menu_selection == 7:
            display_specific_result_box()
        elif menu_selection == 8:
            # Requirement 11: Exit verification confirmations handled natively
            assert_exit = messagebox.askyesno(
                "Exit", "Are you sure you want to exit?")
            if assert_exit:
                print("Shutting down core operating matrices... Goodbye.")
                break
        else:
            print(
                "Command signature index matching out of range parameters. Try keys between 1 and 8.")


if __name__ == "__main__":
    run_system_orchestrator()

    # Alzahrani, N. and Vahid, F., 2021, July. Common logic errors for programming learners: A three-decade literature survey. In 2021 ASEE Annual Conference & Exposition (pp. 1-15). American Society for Engineering Education.
# Bobrow, D.G. and Stefik, M., 1983. The LOOPS manual (Vol. 10). Palo Alto, CA: Xerox Corporation.
# Byckling, P. and Sajaniemi, J., 2006. Roles of variables and programming skills improvement. ACM SIGCSE Bulletin, 38(1), pp.413-417.
# Cobham, A., Fridshal, R. and North, J.H., 1961, October. An application of linear programming to the minimization of Boolean functions. In 2nd Annual Symposium on Switching Circuit Theory and Logical Design (SWCT 1961) (pp. 3-9). IEEE.
# Denny, P., Luxton-Reilly, A. and Tempero, E., 2012, July. All syntax errors are not equal. In Proceedings of the 17th ACM annual conference on Innovation and technology in computer science education (pp. 75-80).
# Eghbali, A. and Pradel, M., 2020, December. No strings attached: An empirical study of string-related software bugs. In Proceedings of the 35th IEEE/ACM International Conference on Automated Software Engineering (pp. 956-967).
# Furman, S., Boehm-Davis, D.A. and Holt, R.W., 2002. A Look at Programmers Communicating through Program Indentation. Journal of the Washington Academy of Sciences, pp.73-88.
